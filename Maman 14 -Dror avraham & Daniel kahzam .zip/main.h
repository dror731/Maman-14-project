#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include "print_files.h"

#define SIZE 81
#define LABEL_SIZE 31






